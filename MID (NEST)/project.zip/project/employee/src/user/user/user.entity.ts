import { Entity, Column, PrimaryGeneratedColumn, BeforeInsert } from 'typeorm';
import * as bcrypt from 'bcrypt';

@Entity()
export class user {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;


  @Column('text', { nullable: true })
  signupToken: string | null;   // 🎯 Token generated on signup (one-time)

  @Column('text', { nullable: true })
  loginToken: string | null;    // 🎯 Token generated when user logs in

  @Column('text', { nullable: true })
  otp: string | null;           // 🎯 OTP for password reset



}
