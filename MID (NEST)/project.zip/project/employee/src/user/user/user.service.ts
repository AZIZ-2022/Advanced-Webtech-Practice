import { Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { user } from 'src/user/user/user.entity';
import { createuser } from 'src/user/user/DTO/user.dto';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(user) private userRepo: Repository<user>,
  ) {}

  // View the profile of the logged-in user
  async viewProfile(token: string) {
    const user = await this.userRepo.findOne({ where: { loginToken: token } });

    if (!user) {
      throw new NotFoundException('User not found or invalid token');
    }

    return user;
  }

  // Update the profile of the logged-in user
  async updateProfile(token: string, updateUserDto: createuser) {
    const user = await this.userRepo.findOne({ where: { loginToken: token } });

    if (!user) {
      throw new NotFoundException('User not found or invalid token');
    }

    // Update user properties
    Object.assign(user, updateUserDto);
    await this.userRepo.save(user);

    return { message: 'Profile updated successfully', user };
  }

  // Delete the profile of the logged-in user
  async deleteProfile(token: string) {
    const user = await this.userRepo.findOne({ where: { loginToken: token } });

    if (!user) {
      throw new NotFoundException('User not found or invalid token');
    }

    await this.userRepo.remove(user);

    return { message: 'Profile deleted successfully' };
  }
}

