import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { car } from './car.entity';
import { cardto } from 'src/car/car/DTO/car.dto';
import { user } from 'src/user/user/user.entity';



@Injectable()
export class CarService {
  constructor(
    @InjectRepository(car) private carRepo: Repository<car>,
    @InjectRepository(user) private userRepo: Repository<user>,
  ) {}


  async findUserByToken(token: string) {
    return this.userRepo.findOne({ where: { loginToken: token } });
  }

  // Add a new car
  async addCar(carDto: cardto) {
    const newCar = this.carRepo.create(carDto);
    await this.carRepo.save(newCar);
    return { message: 'Car added successfully!', car: newCar };
  }

  // Get a list of all cars
  async getAllCars() {
    return await this.carRepo.find();
  }

  // Get car details by ID
  async getCarById(id: number) {
    const car = await this.carRepo.findOne({ where: { id } });
    if (!car) {
      throw new NotFoundException('Car not found');
    }
    return car;
  }

  // Update car details by ID
  // 🚀 Update Car
  async updateCar(id: number, carDto: cardto) {
    const car = await this.carRepo.findOne({ where: { id } });
    if (!car) {
      throw new NotFoundException('Car not found');
    }

    // Update car fields
    Object.assign(car, carDto);
    await this.carRepo.save(car);

    return { message: 'Car updated successfully!', car };
  }


  // Delete car by ID
  async deleteCar(id: number) {
    const car = await this.carRepo.findOne({ where: { id } });
    if (!car) {
      throw new NotFoundException('Car not found');
    }

    await this.carRepo.remove(car);
    return { message: 'Car deleted successfully' };
  }








}
