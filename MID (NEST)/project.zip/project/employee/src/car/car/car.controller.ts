import {Controller,Post,Get,Patch,Delete,Body,Param,Headers,UnauthorizedException,UsePipes,ValidationPipe} from '@nestjs/common';
import { CarService } from './car.service';
import { cardto } from 'src/car/car/DTO/car.dto';
import { user } from 'src/user/user/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Controller('/car')
export class CarController {
  constructor(
    private readonly carService: CarService,
    @InjectRepository(user)
    private userRepo: Repository<user>,
  ) {}

  // Utility to verify token from headers
  async verifyToken(authHeader: string): Promise<user> {
    if (!authHeader) {
      throw new UnauthorizedException('Authorization token is required');
    }

    // Remove 'Bearer ' prefix if present
    const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : authHeader;

    const user = await this.userRepo.findOne({ where: { loginToken: token } });
    if (!user) {
      throw new UnauthorizedException('Invalid or missing token');
    }

    return user;
  }

  @Post('add')
  @UsePipes(new ValidationPipe())
  async addCar(@Body() carDto: cardto, @Headers('authorization') authHeader: string) {
    // Validate token before processing
    await this.verifyToken(authHeader); // This will throw UnauthorizedException if the token is missing/invalid
    return this.carService.addCar(carDto);
  }

  @Get('all')
  async getAllCars(@Headers('authorization') authHeader: string) {
    // Validate token before processing
    await this.verifyToken(authHeader); // This will throw UnauthorizedException if the token is missing/invalid
    return this.carService.getAllCars();
  }

  @Get(':id')
  async getCarById(@Param('id') id: number, @Headers('authorization') authHeader: string) {
    // Validate token before processing
    await this.verifyToken(authHeader); // This will throw UnauthorizedException if the token is missing/invalid
    return this.carService.getCarById(id);
  }

  @Patch(':id/update')
  @UsePipes(new ValidationPipe())
  async updateCar(
    @Param('id') id: number,
    @Body() carDto: cardto,
    @Headers('authorization') authHeader: string,
  ) {
    // Validate token before processing
    await this.verifyToken(authHeader); // This will throw UnauthorizedException if the token is missing/invalid
    return this.carService.updateCar(id, carDto);
  }

  @Delete(':id/delete')
  async deleteCar(@Param('id') id: number, @Headers('authorization') authHeader: string) {
    // Validate token before processing
    await this.verifyToken(authHeader); // This will throw UnauthorizedException if the token is missing/invalid
    return this.carService.deleteCar(id);
  }
}
