import { Injectable, ConflictException, NotFoundException, UnauthorizedException, BadRequestException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { user } from 'src/user/user/user.entity';
import { createuser } from 'src/user/user/DTO/user.dto';
import * as nodemailer from 'nodemailer';
import { randomBytes } from 'crypto';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(user) private userRepo: Repository<user>,
    private jwtService: JwtService,
  ) {}

  // 🚀 SIGNUP
  async signup(dto: createuser) {
    const existing = await this.userRepo.findOne({ where: { email: dto.email } });
    if (existing) throw new ConflictException('Email already registered');

    const signupToken = randomBytes(32).toString('hex');
    const newUser = this.userRepo.create({ ...dto, signupToken });
    await this.userRepo.save(newUser);

    return { message: 'Signup successful!', signupToken };
  }

  // 🚀 LOGIN
  async login(email: string, password: string) {
    const userFound = await this.userRepo.findOne({ where: { email } });

    if (!userFound || userFound.password !== password) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const loginToken = randomBytes(32).toString('hex');
    userFound.loginToken = loginToken;
    await this.userRepo.save(userFound);

    return { message: 'Login successful', loginToken };
  }

 
  async logout(loginToken: string) {
    const userFound = await this.userRepo.findOne({ where: { loginToken } });
    if (!userFound) throw new NotFoundException('Invalid token or already logged out');
  
    userFound.loginToken = null;
    await this.userRepo.save(userFound);
  
    return { message: 'Logged out successfully' };
  }
  

  // 🚀 FORGOT PASSWORD (Send OTP)
  async forgotPassword(email: string, token: string) {
    const userFound = await this.userRepo.findOne({ where: { email } });
    if (!userFound) throw new NotFoundException('Email not registered');

    if (userFound.loginToken) {
      throw new UnauthorizedException('Logout first before resetting password.');
    }

    if (userFound.signupToken !== token) {
      throw new UnauthorizedException('Invalid signup token.');
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
    userFound.otp = otp;
    await this.userRepo.save(userFound);

    await this.sendOtpEmail(userFound.email, otp);

    return { message: 'OTP sent to your email' };
  }


  async resetPassword(email: string, otp: string, newPassword: string) {
    const userFound = await this.userRepo.findOne({ where: { email } });
    if (!userFound) throw new NotFoundException('Email not registered');

    if (userFound.loginToken) {
      throw new UnauthorizedException('Logout first before resetting password.');
    }

    if (userFound.otp !== otp) {
      throw new BadRequestException('Invalid OTP');
    }

    userFound.password = newPassword;
    userFound.otp = null; // Clear OTP after success
    await this.userRepo.save(userFound);

    return { message: 'Password reset successful' };
  }

  
  private async sendOtpEmail(toEmail: string, otp: string) {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'aziz22470131@gmail.com', // your email
        pass: 'rklw aahk qxxh tpvu', // your email app password
      },
    });

    const mailOptions = {
      from: 'aziz22470131@gmail.com',
      to: toEmail,
      subject: 'Password Reset OTP',
      text: `Your OTP for password reset is: ${otp}`,
    };

    await transporter.sendMail(mailOptions);
  }
}
